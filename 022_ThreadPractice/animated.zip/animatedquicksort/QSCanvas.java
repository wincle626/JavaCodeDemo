import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public class QSCanvas extends JFrame {
	private final int XDISP = 10;
 	private JTextField maxProcField;
//	private String strings[] = {"Metal","Motif"};
//	private UIManager.LookAndFeelInfo looks[];
//	private JRadioButton radio[];

	private DrawPanel drawingArea;
	private JPanel interactPanel;
	private JTextField numProcField;
	private JButton startButton;
	private JButton quitButton;
	private JButton initButton;
	private JSlider maxProcessSlider;	
	private Main boss;
	private int height;
	private int maxMaxProc;
	private Monitor	monitor;
	
	public QSCanvas (Main m, Monitor mon, int w, int h, int initMaxProc, int maxMaxProc) {
		boss = m;
		monitor = mon;
		
		this.maxMaxProc = maxMaxProc;
		maxProcessSlider = new JSlider(SwingConstants.HORIZONTAL,1,maxMaxProc,initMaxProc);
		maxProcessSlider.setMajorTickSpacing (5);
		maxProcessSlider.setPaintTicks (true);
		maxProcessSlider.addChangeListener ( 
			new ChangeListener () {
				public void stateChanged (ChangeEvent e) {
				   boss.setMaxAccess(maxProcessSlider.getValue());
				   maxProcField.setText(""+maxProcessSlider.getValue());				   
				   System.out.println("Changed max processes to "+maxProcessSlider.getValue());
				}
			});

		JPanel interactPanel = new JPanel();
		interactPanel.setLayout(new FlowLayout());
		maxProcField = new JTextField(3);
		TextFieldHandler editHandler = new TextFieldHandler();
		maxProcField.addActionListener(editHandler);
		maxProcField.setText(""+maxProcessSlider.getValue());
		interactPanel.add(maxProcField);
		JLabel curProcLabel = new JLabel("Processes:");
		interactPanel.add(curProcLabel);
		
		numProcField = new JTextField(3);
		numProcField.addActionListener(editHandler);
		numProcField.setText("0");
		numProcField.setEditable(false);
		interactPanel.add(numProcField);
						
		startButton = new JButton("Start");
		ButtonHandler buttonHandler = new ButtonHandler();
		startButton.addActionListener(buttonHandler);
		interactPanel.add(startButton);
		initButton = new JButton("Init");
		initButton.addActionListener(buttonHandler);
		interactPanel.add(initButton);
		quitButton = new JButton("Quit");
		quitButton.addActionListener(buttonHandler);
		interactPanel.add(quitButton);

/*		radio = new JRadioButton[strings.length];
		ButtonGroup group = new ButtonGroup();
		ItemHandler lookAndFeelHandler = new ItemHandler();
		for (int i=0; i<radio.length; i++) {
			radio[i] = new JRadioButton(strings[i]);
			radio[i].addItemListener(lookAndFeelHandler);
			group.add(radio[i]);
			interactPanel.add(radio[i]);
	    }
*/
		drawingArea = new DrawPanel(w,h);

		Container c = getContentPane ();
		c.add (maxProcessSlider, BorderLayout.NORTH);
		c.add (interactPanel, BorderLayout.SOUTH);
		c.add (drawingArea, BorderLayout.CENTER);
//		looks = UIManager.getInstalledLookAndFeels();
//		System.out.println("Getting started...");
		setSize(Math.max(400,w+2*XDISP),Math.max(300,h+50));
		show();
//		radio[0].setSelected(true);
	}

	private void noStartAllowed() {
		startButton.setEnabled(false);		
	}
	
	public void allowStart() {
		startButton.setEnabled(true);
	}
	
	public void noInitAllowed () {
		initButton.setEnabled(false);
	}
	
	public void allowInit () {
		initButton.setEnabled(true);
	}

//	private void changeTheLookAndFeel (int value) {
//		try {
//			UIManager.setLookAndFeel(looks[value].getClassName() );
//			SwingUtilities.updateComponentTreeUI(this);
//		}
//		catch (Exception e) {
//			e.printStackTrace();
//		}
//	}
    
	private class TextFieldHandler implements ActionListener {
		public void actionPerformed(ActionEvent e) {
		if (e.getSource()==maxProcField) {
			int val = Math.min(maxMaxProc,Integer.parseInt(e.getActionCommand()));
			boss.setMaxAccess(val);
			maxProcessSlider.setValue(val);
			maxProcField.setText(""+val);
			System.out.println("Changing max processes to "+val);
		}
		else { // Do nothing.
		}
		}
	}

	private class ButtonHandler implements ActionListener {
		public void actionPerformed (ActionEvent e) {
			if (e.getSource()==quitButton) {
				System.exit(0);
			}
			else 
				if (e.getSource()==startButton) {
					noStartAllowed();
					boss.startSorting();
				}
				else {
					noInitAllowed();
					boss.reInit();
				}
		}
	}
	
//    private class ItemHandler implements ItemListener {
//		public void itemStateChanged (ItemEvent e) {
//		  for (int i = 0; i<radio.length; i++)
//		  	if (radio[i].isSelected()) 	
//		      changeTheLookAndFeel(i);
//		}
//	}
	
	private class DrawPanel extends JPanel {
    	private int width;
		private int height;
	
		public DrawPanel (int w, int h) {
			width = w;
			height = h;
		}
	
	    public void paintComponent(Graphics g) {
			super.paintComponent(g);
	        g.setColor(Color.red);
	        for( int i=0; i<boss.array.length; i++ ) {
	            g.drawLine(i+XDISP, height,i+XDISP,height-boss.array[i]);
	        }
        }
    }

	public void update( Graphics g ) {
		numProcField.setText(""+monitor.numberOfProcAtWork ());
    	paint( g );
    }                                                                       
	
}
