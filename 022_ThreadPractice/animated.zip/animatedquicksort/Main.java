import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import java.text.DecimalFormat;

class Main {
    private final int SIZE = 400;
	private final int INITTHREADS = 4;
    private final int MAXVALUE = 300;
  	private final int MAXPROC = 25;
    public int array[];
    Thread drawTimer;
	QSCanvas theCanvas;
	Monitor monitor;
	ThreadQuickSort tqs;
		
	public Main() {
        fillArray(SIZE);
	    monitor = new Monitor (INITTHREADS);
	    theCanvas = new QSCanvas(this,monitor,SIZE,MAXVALUE,monitor.getMaxAccess(),MAXPROC);
        drawTimer = new Thread(new DrawTimer(this));
        drawTimer.start();
    }              

	private void fillArray (int size) {
    	array = new int[size];
		
        for (int i=0; i< size; i++)
        	array[i] = (int)( Math.random()*(MAXVALUE-1) + 1 ) ;
    }

	public void setMaxAccess (int maximum) {	
		monitor.setMaxAccess(maximum);
	}
	
	public String toString () {
    	String x = "";
        DecimalFormat threeDigits = new DecimalFormat(" 000");
        for (int i=0; i<array.length; i++)
        	x += threeDigits.format(array[i]);
        return x;
    }

	public void repaint() {
		theCanvas.repaint();
	}

	public void startSorting () {
		tqs = new ThreadQuickSort(monitor,array,0,SIZE-1);
		monitor.addWaitingProcess();
		tqs.start();
	}

	public void reInit () { // Not yet satisfactory.
		WaitThread waitThread = new WaitThread();
		waitThread.start();
	}

	class WaitThread extends Thread {
		public void run () {
			while (!monitor.allDone()) {
			  try {
			     Thread.sleep(500);
			  }
			  catch (Exception e) {}			
			}
        	fillArray(SIZE); // Fill it again
			theCanvas.allowStart();
			theCanvas.allowInit();		
		}
	}

	// Below the entry point to the program.		
	public static void main (String args[]) {
        Main m = new Main ();
    }
}
