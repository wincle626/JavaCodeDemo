class DrawTimer implements Runnable {
	private int repaintTime;
 	private Main boss;
	
	public DrawTimer (Main m) {
	  repaintTime = 5;
	  boss = m;
    }

  	public void run () {
        while(true) {
           	try {
               Thread.sleep(repaintTime) ;
		   	}
           	catch( InterruptedException ie ) {}			 
           	boss.repaint();
      	}
    }
}	
