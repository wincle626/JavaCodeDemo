import java.awt.*;
import java.awt.event.*;

class ThreadQuickSort extends Thread {
	private int array[];
	private int begin;
	private int end;
	private Monitor monitor;
	private final int SWAPTIME = 50;
	
	public ThreadQuickSort (Monitor m, int a[], int from, int to) {
		monitor = m;
		array = a;
		begin = from;
		end = to;
	}
	
	private void swap(int first, int second) {
       int temp = array[first];
       array[first] = array[second];
       array[second] = temp;
       try  {
  		  sleep (SWAPTIME);
	   }
	   catch (InterruptedException ie) {}		
    }
 
    public int split(int bound, int lower, int upper) {
       while (lower <= upper) {
          while (array[lower]<bound)
             lower++;
          while (bound < array[upper])
             upper--;
          if (lower < upper)
             swap(lower++,upper--);
          else
             lower++; // Make sure we get out of the loop
       }
       return upper;
    }
 
    /* The main sorting function. The parameters specify which part of the array should be sorted. */
    public void sort (int from, int to) {
      if (from >= (to-1)) {
         // Handle arrays up to length 2.
         if (from >= to)
            return;
         else
           if (array[from] > array[to])
             swap (from,to);															
      }
      else { // Array is guaranteed to hold three elements.
        int limit = split(array[(from+to)/2],from,to); // Best choice for almost sorted arrays
		ThreadQuickSort rightPart = new ThreadQuickSort(monitor,array,limit+1,to);
		monitor.addWaitingProcess(); // To avoid problems with termination detection
        rightPart.start(); // Concurrently do right part
        sort(from,limit); // Do the left part yourself
	  }
    }
	
	public void run () {
		monitor.getPermissionToContinue();
		sort (begin,end);
		monitor.relinquishPermission();
	}
}
