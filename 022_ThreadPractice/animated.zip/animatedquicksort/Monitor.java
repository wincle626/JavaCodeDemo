/*
	Encapsulates all shared material and hence all synchronized methods.
	Actually this monitor mimicks an n-valued semaphore.
*/

public class Monitor {
	private int maxAccess;
	private int nowAccess;
	private int waiting;
		
	public Monitor () {
		this(1);
	}
	
	public Monitor (int n) {
		if (n>=0) {
			maxAccess = n;
			waiting = 0;
			nowAccess = 0;
		}
		else {
			System.out.println ("Negative number of processors");
			System.exit(-1);
		}
	}

	public int numberOfProcAtWork () {
		return nowAccess;
	}
	
	public synchronized void addWaitingProcess () {
		waiting++;
	}
		
	public synchronized void getPermissionToContinue() {
		while (nowAccess>=maxAccess) { // In case of NotifyAll()
			try {
			  wait();
			}
			catch (InterruptedException ie) { // Should never occur.
				System.out.println("Where is this interrupt coming from!");
				System.exit(-1);
			}
		}
		waiting = waiting-1; // One got through and is now not waiting anymore.
		nowAccess++;
	}

	public synchronized boolean allDone () {
		return (nowAccess+waiting==0);
	}
		
	public synchronized void relinquishPermission () {
		nowAccess--;
		notify();	
	}

	public int getMaxAccess () {
		return maxAccess;
	}
		
	public synchronized void setMaxAccess (int n) {
		if (n>=0) {
			maxAccess = n;
			notifyAll();
		}
		else {
			System.out.println ("Negative number of processors");
			System.exit(-1);
		}
	}
}
